-- Currently running CryptoCoin miner
-- 
-- reference:
--   * https://github.com/Neo23x0/signature-base/blob/master/yara/pua_cryptocoin_miner.yar
--
-- tags: persistent
-- interval: 3600
-- platform: posix
SELECT
  yara.*,
  -- Child
  p0.pid AS p0_pid,
  p0.path AS p0_path,
  p0.name AS p0_name,
  p0.start_time AS p0_start,
  p0.cmdline AS p0_cmd,
  p0.cwd AS p0_cwd,
  p0.cgroup_path AS p0_cgroup,
  p0.euid AS p0_euid,
  p0_hash.sha256 AS p0_sha256,
  -- Parent
  p0.parent AS p1_pid,
  p1.path AS p1_path,
  p1.name AS p1_name,
  p1.start_time AS p1_start,
  p1.euid AS p1_euid,
  p1.cmdline AS p1_cmd,
  p1_hash.sha256 AS p1_sha256,
  -- Grandparent
  p1.parent AS p2_pid,
  p2.name AS p2_name,
  p2.start_time AS p2_start,
  p2.path AS p2_path,
  p2.cmdline AS p2_cmd,
  p2_hash.sha256 AS p2_sha256
FROM
  processes p0
  JOIN yara ON p0.path = yara.path
  LEFT JOIN hash p0_hash ON p0.path = p0_hash.path
  LEFT JOIN processes p1 ON p0.parent = p1.pid
  LEFT JOIN hash p1_hash ON p1.path = p1_hash.path
  LEFT JOIN processes p2 ON p1.parent = p2.pid
  LEFT JOIN hash p2_hash ON p2.path = p2_hash.path
WHERE
  p0.start_time > (strftime('%s', 'now') - 3600)
  AND yara.sigrule = '    
    rule cryptexec {
    strings:
        $c0 = "crypto/cipher.newCBC" ascii
        $c1 = "crypto/aes.newCipher"
        $e0 = "os/exec.(*Cmd).Run" ascii
        $e1 = "os/exec.Command" ascii
    condition:
        3 of them
}'
  AND yara.count > 0
  AND p0.path NOT LIKE "/Users/%/go/bin/%"
  AND p0.path NOT LIKE "/home/%/go/bin/%"
  AND p0.path NOT LIKE "/Users/%/dev/%"
  AND p0.path NOT LIKE "/home/%/dev/%"
  AND p0.path NOT LIKE '%docker%'
  AND p0.path NOT LIKE '%tailscale%'
  AND p0.path NOT LIKE '%terraform%'
  AND p0.path NOT LIKE '%rootlesskit%'
  AND p0.path NOT LIKE '/opt/homebrew/%'
  AND p0.path NOT LIKE '/private/var/folders/%/T/go-build%'
  AND p0.name NOT IN (
    'buildkit',
    'buildkitd',
    'cloud_sql_proxy',
    'containerd',
    'crane',
    'op',
    'kubectl',
    'go',
    'docker',
    'lima-guestagent',
    'containerd-star',
    'gopls',
    'launcher',
    'tflint',
    'cloud-sql-proxy',
    'pprof',
    'lens-k8s-proxy',
    'rootlesskit',
    'snap',
    'snapd',
    'sourcegraph-backend',
    'terraform-ls',
    'velociraptor',
    'wolfictl'
  )
  AND p1.name NOT LIKE "%docker%"
